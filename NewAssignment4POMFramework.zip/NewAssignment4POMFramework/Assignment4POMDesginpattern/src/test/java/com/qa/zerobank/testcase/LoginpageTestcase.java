package com.qa.zerobank.testcase;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.TestBase.TestBase;
import com.qa.zerobank.TestUtill.TestUtill;

import com.qa.zerobank.pages.AccountSummarypage;

import com.qa.zerobank.pages.Homepage;

import com.qa.zerobank.pages.Loginpage;



public class LoginpageTestcase extends TestBase{
	
	Homepage homePage;
	Loginpage logInPage;
	AccountSummarypage accountSummaryPage;
	TestUtill testutill;
	String sheetName = "ZerobankNegativetestcasedata";
	
	public LoginpageTestcase() {
		super();
	}
	@BeforeMethod
	  public void beforeMethod() {
		  intialization();
			homePage = new Homepage();
			logInPage = new Loginpage();
			accountSummaryPage = new 	AccountSummarypage();
			testutill=new TestUtill();
	  }
	 @AfterMethod
	  public void afterMethod() {
		  
			driver.close();
			driver.quit();
	 }
	 
	 
	 @Test
	 public void loginInvalidtestcase() {
		 
	 homePage.clickOnSignInButton();
	 logInPage.loginInvalid("sdfasdf", "hffhofjlk");
	 logInPage.loginInvalid("yteutwiowo", "       ");
	 logInPage.loginInvalid("    ", "      ");
	 logInPage.loginInvalid("@$^%%*&*", "#%&^&#");
	 logInPage.loginInvalid("123456", "6788544");
	 logInPage.loginInvalid("     ", "bdcbjdhidh");
	 }
	
	 


	@Test
		public void loginvalidtestcase() {
		 homePage.clickOnSignInButton();
			 logInPage.loginvalid("username", "password");
			
		}
			
			
		}
	 


