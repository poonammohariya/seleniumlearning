package com.demo.Testpages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.demo.base.TestBase;

public class Dashboard extends TestBase {
	
//	@FindBy(id="txtUsername")
//	WebElement username;
//	
//	@FindBy(name="txtPassword")
//	WebElement password;
//	
//	
//	@FindBy(id="btnLogin")
//	WebElement loginbutton;
//	
	@FindBy(xpath="//b[contains(text(),'Recruitment')]")
	WebElement recruitment;	
	
	@FindBy(id="btnAdd")
	WebElement Addbtn;
	
	@FindBy(name = "addCandidate[firstName]")
	WebElement Fullname;
	
	@FindBy(name="addCandidate[lastName]")
	WebElement lastname;
	
	@FindBy(name = "addCandidate[email]")
	WebElement email;
	
	@FindBy(id = "btnSave")
	WebElement save;
	
	@FindBy(id="btnSrch")
	WebElement search;
	
	public Dashboard() {
		PageFactory.initElements(driver, this);
	
	
	}
	public void clickonadd() {
		Addbtn.click();
		
	}
	public void enterfirstname() {
		Fullname.sendKeys("Poonam");
		
	}
	public void enterLastname() {
		lastname.sendKeys("Mohariya");
		
	}
	public void enteremail() {
		email.sendKeys("abcd@gmail.com");
	}
	public void clickonSave() {
		save.click();
	}
	public void clickonSearch() {
		search.click();
	}
//	public Dashboard clickonlogIn() {
//		username.sendKeys(prop.getProperty("userid"));
//		password.sendKeys(prop.getProperty("pwd"));
//		loginbutton.click();
//		
//		return new Dashboard();
}

