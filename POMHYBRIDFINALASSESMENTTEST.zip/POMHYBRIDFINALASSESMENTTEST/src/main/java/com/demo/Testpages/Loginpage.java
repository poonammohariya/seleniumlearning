package com.demo.Testpages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.demo.base.TestBase;


public class Loginpage extends TestBase {
	@FindBy(id="txtUsername")
	static
	WebElement username;
	
	@FindBy(name="txtPassword")
	static
	WebElement password;
	
	
	@FindBy(id="btnLogin")
	static
	WebElement loginbutton;
	
	

	// Initializing the Page Objects:
	public Loginpage() {
		PageFactory.initElements(driver, this);
	}
	

	public static void clickonlogIn() {
		try {
			username.sendKeys(prop.getProperty("userid"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		password.sendKeys(prop.getProperty("pwd"));
		loginbutton.click();
		
		;
		
		
	}

}



