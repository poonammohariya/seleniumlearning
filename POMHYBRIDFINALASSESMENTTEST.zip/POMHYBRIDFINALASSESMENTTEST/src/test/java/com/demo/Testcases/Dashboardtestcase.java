package com.demo.Testcases;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.demo.Testpages.Dashboard;
import com.demo.base.TestBase;


public class Dashboardtestcase extends TestBase {
	Dashboard dashboard;
	LoginPageTestcase logInPage;
	
	
	
	public Dashboardtestcase() {
		super();
	}
	
	
	
	@AfterMethod
	public void cleanUp () {
		driver.close();
		driver.quit();	
	}
	
	
@Test
public void clickonRecuirment() {
	WebElement ele = driver.findElement(By.xpath("//b[contains(text(),'Recruitment')]"));
	Actions action =new Actions(driver);
	action.moveToElement(ele).build().perform();
	
}
public void clickonaddTestcase() {
	dashboard.clickonadd();
	
}
public void enterfirstnameTestcase() {
	dashboard.enterfirstname();
}
public void enterLastnameTestcase() {
	dashboard.enterLastname();
	}

public void enteremailTestcase() {
	dashboard.enteremail();
}
public void clickonSaveTestcase() {
	dashboard.clickonSave();
}
public void clickonSearchTestcase() {
	dashboard.clickonSearch();
}
		
	
	}


