package com.demo.Testcases;

import org.testng.annotations.AfterMethod;

import org.testng.annotations.Test;

import com.demo.Testpages.Dashboard;
import com.demo.Testpages.Homepage;
import com.demo.Testpages.Loginpage;
import com.demo.base.TestBase;


public class LoginPageTestcase extends TestBase{
	Dashboard dashboard;
	LoginPageTestcase logInPage;
	Homepage homepage;
	Loginpage login;
	
	
	public LoginPageTestcase() {
		super();
	}
	
  

  @AfterMethod
  public void afterMethod() {
	  	// close driver
		driver.close();
		driver.quit();
  }
  @Test
	public void LogIn() {
	  Loginpage.clickonlogIn();
	 
	  
	  
	
	  
	
	
	}

}
